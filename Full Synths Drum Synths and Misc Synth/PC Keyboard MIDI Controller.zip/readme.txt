
  ***********************************************************
  All the text below is better seen by clicking on the "ClickMe.htm" file.
  ***********************************************************
  
  This project adapted for the AVR Tiny11 ($0.56 each at DigiKey.com) 
  is in the ZIP file KBtiny11.zip included with the other files.
  
  Guide to using the PC_keyboard-to-MIDI_note adapter and AVR code.
  
  ( -Alan Probandt  November 10, 2003  alan_probandt@yahoo.com)
  
  
  A PC keyboard can be a excellent alternative to a full-sized piano keyboard. It's light, portable, 
  inexpensive, and standard throughout the world.  It allows a tone module, connected to a small amplifier or 
  boom box,  to be easily used as a portable instrument that provides a wide range of musical
  voices ready to be added to a small musical group or impromptu guitar jam session.  It adds new life to old
  tone modules previously locked into a studio rack or stored in a closet.
  
  This adapter allows a standard PC keyboard to be used as a MIDI note generator. Pressing down a key
  on the PC keyboard sends a MIDI note-on message and releasing the key sends a MIDI note-off message.
  The function keys select a new voice by sending a MIDI program change message.  The keypad allows you
  to enter two digits to select a new voice also with a program change message.
 
 On a small piece of perfboard, build the circuit shown in the schematic diagram "schemtic.gif".
 
  - Plugging it in
    
  There are three connections to the little board.  The power connector is a +8 to +15 volt DC source 
  which is usually a 'wall-wart' battery adapter.  This provides power for both the processor inside 
  the PC keyboard and the AVR microcontroller on the little board.  Most modern PS2 keyboards (with
  a Mini-DIN6 connector, same as a mouse) use less than 10 milliAmps of current and the AVR processor
  uses about 5 milliAmps.  Therefore the power adapter does not have to be very big.  Even a 9V battery
  will work OK for at least four hours.
  
  The PC keyboard should be plugged into the Mini DIN 6 connector and the MIDI cable goes into the 
  larger DIN 5 connector.  The other end of the MIDI cable goes into the MIDI INPUT of the synthesizer
  tone module.
  
  
  -Playing it
  
  All the MIDI commands from the adapter are sent on MIDI channel one. 
  
  The four rows of alphanumeric keys (1,2,...  - Q,W,E,R,... - A,S,D.... - Z,X,C...) correspond to two
  rows of piano keys.  The 1,2,... row is the black keys (sharps and flats) and the Q,W,E,... row is the 
  white keys of the first (lower octave) piano key row.  The A,S,D... is the black key row and the Z,X...
  is the white key row of the second group of piano keys.  There's three and a half octaves total range.
  Please see the diagram GIF file "MIDIkeys.gif" for the exact correspondence between keys and notes.
  Pressing the space bar sends the All_Notes_Off command (" B0 7B 00 ").
  
  Pressing the Caps-Lock key toggles the Sustain petal.  After the first press of the Caps-Lock key, all the 
  key presses will send only the Note-On MIDI message.  The notes remain sounding after the key is released.
  The second press of the Caps Lock key turns off the sustain.  Now, releasing the key will send a Note-off
  MIDI message for that key.
  
  This range can be shifted up or down by octave using the Up-Arrow and Down-Arrow keys.  The DOWN arrow
  (towards the front of the keyboard) shifts the range higher in frequency by one octave and the UP arrow
  (pointing towards the back of the keyboard) shifts the range lower in pitch by an octave.
  
  
  -Changing the Synthesizer voices
  
  The function keys F1 to F12 correspond to the first twelve voices of the tone module when the adapter
  is first powered on.  For example pressing F2 sends the MIDI command " C0 01 " (these are hex numbers
  of the MIDI protocol) to the tone module that will change the voice to number two).  Pressing the ALT
  key and a function key will assign the current voice number to the selected function key.  
  
  You can select the next voice number with the Right-Arrow key and the previous voice number with the
  Left-Arrow key.  Pressing the Left-Arrow at voice one (hex 00) rolls the voice number to 128 (hex 7f),
  and the Right-Arrow key will roll-over to voice one (hex 00) when at voice 128. 
  
  You can select an individual voice number from 00 to 99 by entering two digits on the key pad. If voice
  24 is an excellent string pad then you can activate it by pressing '2' then '3'.  Since internal MIDI
  voice numbers start a 0 instead of 1, the voice listings in the manual will be one greater than the 
  digit selection. 
  
  -Limitations
  
  The PC keyboard was engineered for typists who rarely have more than two keys pressed at a time. Therefore
  the keys are scanned by the keyboard's internal CPU in rows and columns.  This means that some key combinations
  don't get acknowledged at all.  On my keyboard there is a 'dead spot' near the 'P' key that only plays one note at
  a time.  If this causes a problem for your playing style, try shifting the octave range to another part of the keyboard.
  
  -Suggestions
  
 - Use the UART of the AVR AT90S2313 to add PC serial port MIDI access.
 - Split the keyboard top and bottom between two MIDI voices.
  -Add an EEPROM chip to store custom voice information that gets sent to the tone module.  This allows 
  custom voices to be added to tone modules like the Roland MT-32 that don't have an internal battery to store data.
  -Add a second MINI DIN6 for a mouse.  Interpret mouse movements as MIDI pitch-bend and Mod wheel data.
  
  ****** The circuit internals and 'PCkb.asm' source code ****
  
  The adapter uses an Atmel AVR microcontroller to read the serial pulses from the keyboard and generate the
  serial pulses for the MIDI interface.  Although designed and coded for the AT90S2313 version of the AVR, the
  code can be used on any chip of the AVR family.  If you use the low-end AVR model AT90S1200, then use the 
  source code file "PCkb1200.asm" instead of "PCkb.asm" because of the limitations of the low-end 1200 model.
  The 1200 code uses a different look-up table for the keypresses than the code for the other AVRs.
  
  This design's AVR system clock is set by a standard 3.579MHz color-burst TV crystal.  Using a different crystal or the 
  internal AVR R-C clock requires adjusting the delay timing value for the MIDI output.  This is the constant 
  called 'b' located in the subroutine PUT_MIDI of the source code.  The input from the keyboard triggers an 
  interrupt with each logic transition and is not dependent on any system clock speed.
  
  Running the ATMEL Windows assembler will give the message "Code Too Big".  To use this assembler, split the
  source file into two parts called PCkb.asm and PCkb2.asm at line 565. Then uncomment the 'include' directive
  located at that line.  Other assemblers don't have this idiotic problem.
  
   The files 2313def.inc and 1200def.inc provide reference definitions for the processors.
  
  *****Atmel AVR resources:  
  
  AVR microcontrollers are available at Digikey.com.   The connectors can be removed from old, used PC motherboards.
  
  PDF data sheets, assemblers, and code simulators  for the Atmel AVR microcontrollers are found at the Atmel website:
  www.atmel.com.  The simulator is called AVRstudio.exe   Version 3.56 is easiest to use and learn.
  
  The best programmer either the Atmel STK500 board for $80 or the free PC parallel port programmer found at:
  "Programming a spider's brain"; a robotics site located at http://www.xs4all.nl/~sbolt
  This program code is SP12.exe.  I've built and used 'Ken's Dongle' to program AVRs with no problems.
  The command line interface is a little tricky, but be patient, make little tests,  and re-read the documentation until
  everything comes together for you.  
  
  GNU AVR C compiliers and lots of information, tutorials, and help is found at: www.AVRfreaks.org
  
  Keyboard interfacing information on the web is at: http://www.beyondlogic.org/keyboard/keybrd.htm 
